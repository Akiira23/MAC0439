/*USUARIO*/

INSERT INTO usuario (user_ID, tel_DDD, tel_Numero, CPF, senha, email, nome, sexo)
   VALUES (1, 19, 35685816, '57132727290', '0PB6iPqx95', 'diogomatheusmonteiro@gmail.com', 'Filipe Edson Mateus Silva', 'M');
INSERT INTO usuario (user_ID, tel_DDD, tel_Numero, CPF, senha, email, nome, sexo)
   VALUES (2, 47, 28745013, '15931038833', 'PbhJytLJkC', 'juanmarcelogalvao_@gmail.com', 'Juan Marcelo Galvão', 'M');
INSERT INTO usuario (user_ID, tel_DDD, tel_Numero, CPF, senha, email, nome, sexo)
   VALUES (3, 62, 29813363, '68473837045', 'mPWC9q2Rb3', 'priscilaanalustefanycampos@gmail.com', 'Priscila Analu Stefany Campos', 'F');
INSERT INTO usuario (user_ID, tel_DDD, tel_Numero, CPF, senha, email, nome, sexo)
   VALUES (4, 61, 26138555, '49047854365', 'DeeI4R7bsQ', 'luziaelianegalvao@gmail.com', 'Luzia Eliane Galvão', 'F');
INSERT INTO usuario (user_ID, tel_DDD, tel_Numero, CPF, senha, email, nome, sexo)
   VALUES (5, 47, 26088981, '58083406678', 'boihd49ggl', 'antoniojoaquim_@gmail.com', 'Antonio Joaquim Juan Jesus', 'M');
INSERT INTO usuario (user_ID, tel_DDD, tel_Numero, CPF, senha, email, nome, sexo)
   VALUES (6, 67, 25343636, '98722709452', 'RyBssatnfg', 'rodrigomurilo2_@gmail.com', 'Rodrigo Murilo Melo', 'M');
INSERT INTO usuario (user_ID, tel_DDD, tel_Numero, CPF, senha, email, nome, sexo)
   VALUES (7, 12, 25757135, '97991120791', '20y1t88BBw', 'isabellajose.2@gmail.com', 'Isabella Josefa Lara da Mata', 'F');
INSERT INTO usuario (user_ID, tel_DDD, tel_Numero, CPF, senha, email, nome, sexo)
   VALUES (8, 21, 29376481, '26917553395', 'iCJHkdfjgP', 'marcosbentoalmada_3@gmail.com', 'Marcos Bento Almada', 'M');
INSERT INTO usuario (user_ID, tel_DDD, tel_Numero, CPF, saldo, senha, email, nome, sexo)
   VALUES (9, 21, 39900409, '60180628445', 2000, 'ON2aE5FRxe', 'guilhermeleonardobarros_21@gmail.com', 'Guilherme Leonardo Barros', 'M');
INSERT INTO usuario (user_ID, tel_DDD, tel_Numero, CPF, saldo, senha, email, nome, sexo)
   VALUES (10, 84, 36819008, '37960945543', 10000, 'f6IcUoD4KQ', 'jorgeguilhermealves_30@gmail.com', 'Jorge Guilherme Alves', 'M');
INSERT INTO usuario (user_ID, tel_DDD, tel_Numero, CPF, saldo, senha, email, nome, sexo)
   VALUES (11, 95, 987911586, '74154656015', 4955, '2lACJaqpFw', 'sophiaanadaianecarvalho_1@gmail.com.br', 'Sophia Ana Daiane Carvalho', 'F');
INSERT INTO usuario (user_ID, tel_DDD, tel_Numero, CPF, saldo, senha, email, nome, sexo)
   VALUES (12, 66, 999909071, '76754167912', 12775, 'Lix9FQHr8E', 'lorenzoyagodossantos_31@gmail.com.br', 'Lorenzo Yago dos Santos', 'M');
INSERT INTO usuario (user_ID, tel_DDD, tel_Numero, CPF, saldo, senha, email, nome, sexo)
   VALUES (13, 73, 994152359, '96249730249', 1960, 'j82QS2dNPA', 'lcalebenricomartingoncalves@gmail.com.br', 'Caleb Enrico Martin Gonçalves', 'M');
INSERT INTO usuario (user_ID, tel_DDD, tel_Numero, CPF, saldo, senha, email, nome, sexo)
   VALUES (14, 42, 994221434, '79678715104', 960, 'qFWSzOF7wQ', 'julioarthurcardoso37@gmail.com.br', 'Julio Arthur Cardoso', 'M');
INSERT INTO usuario (user_ID, tel_DDD, tel_Numero, CPF, saldo, senha, email, nome, sexo)
   VALUES (15, 81, 993190224, '23171730081', 160, 'ZBhLXlPpGg', 'nathanbrunoosvaldoviana_21@gmail.com.br', 'Nathan Bruno Osvaldo Viana', 'M'); 
INSERT INTO usuario (user_ID, tel_DDD, tel_Numero, CPF, saldo, senha, email, nome, sexo)
   VALUES (16, 27, 982020272, '17793692047', 70, 'x38f3SM2iP', 'marciosebastiaonascimento@gmail.com.br', 'Márcio Sebastião Nascimento', 'M');    
INSERT INTO usuario (user_ID, tel_DDD, tel_Numero, CPF, saldo, senha, email, nome, sexo)
   VALUES (17, 47, 982992824, '07419588805', 190, '5QNZZJ5PDw', 'levitheoviniciusbarbosa_10@gmail.com.br', 'Levi Theo Vinicius Barbosa', 'M'); 
INSERT INTO usuario (user_ID, tel_DDD, tel_Numero, CPF, saldo, senha, email, nome, sexo)
   VALUES (18, 81, 36380613, '00250065681', 200, 'JuAbUDc7nF', 'eedsonfelipethiagodepaula@gmail.com.br', 'Edson Felipe Thiago de Paula', 'M');
INSERT INTO usuario (user_ID, tel_DDD, tel_Numero, CPF, saldo, senha, email, nome, sexo)
   VALUES (19, 66, 999041229, '27130076747', 1850, 'wcr8ys8jZs', 'andreabrendadarocha_12@gmail.com.br', 'Andrea Brenda da Rocha', 'F'); 
INSERT INTO usuario (user_ID, tel_DDD, tel_Numero, CPF, saldo, senha, email, nome, sexo)
   VALUES (20, 47, 982422163, '06690624056', 950, 'RsE4oHj3mn', 'victorarthurhenriquedaluz19@gmail.com.br', 'Victor Arthur Henrique da Luz', 'M'); 
INSERT INTO usuario (user_ID, tel_DDD, tel_Numero, CPF, saldo, senha, email, nome, sexo)
   VALUES (21, 96, 983235932, '58417238476', 2500, 'C5DfEyscpJ', 'catarinadaianesoniacastro_70@gmail.com.br', 'Catarina Daiane Sônia Castro', 'F');  
INSERT INTO usuario (user_ID, tel_DDD, tel_Numero, CPF, saldo, senha, email, nome, sexo)
   VALUES (22, 21, 993246081, '84116219878', 6100, 'GqnQzTjAPb', 'sandramarianeagathasilva13@gmail.com.br', 'Sandra Mariane Agatha Silva', 'F');     
   
/*APOSTA*/

INSERT INTO aposta (aposta_ID, valor, aposta_vencedor, odd, data_hora, partida_ID, torneio_ID, id_usuario_aposta)
   VALUES (1, 100, 'Flamengo', 2.3, '2020-04-18 10:34:09 AM', 554, 8, 1);
INSERT INTO aposta (aposta_ID, venceu_aposta, valor, aposta_vencedor, odd, data_hora, partida_ID, torneio_ID, id_usuario_aposta)
   VALUES (2, TRUE, 200, 'C9', 1.6, '2020-05-28 08:04:10 AM', 115, 221, 1);
INSERT INTO aposta (aposta_ID, venceu_aposta, valor, aposta_vencedor, odd, data_hora, partida_ID, torneio_ID, id_usuario_aposta)
   VALUES (3, TRUE, 75, 'Jose23', 1.7, '2020-01-05 10:00:10 PM', 117, 251, 3);
INSERT INTO aposta (aposta_ID, venceu_aposta, valor, aposta_vencedor, odd, data_hora, partida_ID, torneio_ID, id_usuario_aposta)
   VALUES (4, FALSE, 50, 'Joao169', 3.1, '2020-01-05 10:04:00 PM', 117, 251, 2);
INSERT INTO aposta (aposta_ID, valor, aposta_vencedor, odd, data_hora, partida_ID, torneio_ID, id_usuario_aposta)
   VALUES (5, 300, 'Team Liquid', 1.95, '2020-04-18 10:54:59 PM', 554, 8, 2);
INSERT INTO aposta (aposta_ID, valor, aposta_vencedor, odd, data_hora, partida_ID, torneio_ID, id_usuario_aposta)
   VALUES (6, 100, 'Team Liquid', 1.95, '2020-04-18 10:55:10 PM', 554, 8, 4);
INSERT INTO aposta (aposta_ID, valor, aposta_vencedor, odd, data_hora, partida_ID, torneio_ID, id_usuario_aposta)
   VALUES (7, 200, 'Team Liquid', 1.75, '2020-04-18 10:50:59 PM', 554, 8, 5);
INSERT INTO aposta (aposta_ID, venceu_aposta, valor, aposta_vencedor, odd, data_hora, partida_ID, torneio_ID, id_usuario_aposta)
   VALUES (8, FALSE, 100, 'Joao169', 2.8, '2020-01-05 10:05:00 PM', 117, 251, 6);   
INSERT INTO aposta (aposta_ID, venceu_aposta, valor, aposta_vencedor, odd, data_hora, partida_ID, torneio_ID, id_usuario_aposta)
   VALUES (9, TRUE, 100, 'Jose23', 1.75, '2020-01-05 10:01:00 PM', 117, 251, 7);
INSERT INTO aposta (aposta_ID, venceu_aposta, valor, aposta_vencedor, odd, data_hora, partida_ID, torneio_ID, id_usuario_aposta)
   VALUES (10, FALSE, 300, 'TSM', 3.25, '2020-05-28 08:00:00 AM', 115, 221, 8);
INSERT INTO aposta (aposta_ID, venceu_aposta, valor, aposta_vencedor, odd, data_hora, partida_ID, torneio_ID, id_usuario_aposta)
   VALUES (11, FALSE, 300, 'TSM', 5.6, '2020-05-28 08:10:00 AM', 115, 221, 9);
INSERT INTO aposta (aposta_ID, venceu_aposta, valor, aposta_vencedor, odd, data_hora, partida_ID, torneio_ID, id_usuario_aposta)
   VALUES (12, TRUE, 1000, 'C9', 1.95, '2020-05-28 08:20:55 AM', 115, 221, 9);
INSERT INTO aposta (aposta_ID, venceu_aposta, valor, aposta_vencedor, odd, data_hora, partida_ID, torneio_ID, id_usuario_aposta)
   VALUES (13, TRUE, 100, 'TIME 1', 2.1, '2019-04-25 08:20:55 AM', 515, 121, 9);
INSERT INTO aposta (aposta_ID, venceu_aposta, valor, aposta_vencedor, odd, data_hora, partida_ID, torneio_ID, id_usuario_aposta)
   VALUES (14, FALSE, 200, 'Outro time', 1.35, '2019-04-25 08:20:00 AM', 515, 121, 10);
INSERT INTO aposta (aposta_ID, valor, aposta_vencedor, odd, data_hora, partida_ID, torneio_ID, id_usuario_aposta)
   VALUES (15, 1000, 'New Jersey Nets', 2.3, '2019-06-18 08:34:09 PM', 604, 1, 11);
INSERT INTO aposta (aposta_ID, valor, aposta_vencedor, odd, data_hora, partida_ID, torneio_ID, id_usuario_aposta)
   VALUES (16, 3000, 'Boston Celtics', 1.3, '2019-06-18 08:37:09 PM', 604, 1, 12);
INSERT INTO aposta (aposta_ID, valor, aposta_vencedor, odd, data_hora, partida_ID, torneio_ID, id_usuario_aposta)
   VALUES (17, 500, 'Boston Celtics', 1.35, '2019-06-18 08:35:00 PM', 604, 1, 10);
INSERT INTO aposta (aposta_ID, valor, aposta_vencedor, odd, data_hora, partida_ID, torneio_ID, id_usuario_aposta)
   VALUES (18, 700, 'New Jersey Nets', 2.5, '2019-06-18 08:35:00 PM', 604, 1, 13);
INSERT INTO aposta (aposta_ID, venceu_aposta, valor, aposta_vencedor, odd, data_hora, partida_ID, torneio_ID, id_usuario_aposta)
   VALUES (19, TRUE, 1000, 'Alemanha', 1.25, '2020-03-21 09:20:55 PM', 15, 21, 11);
INSERT INTO aposta (aposta_ID, venceu_aposta, valor, aposta_vencedor, odd, data_hora, partida_ID, torneio_ID, id_usuario_aposta)
   VALUES (20, FALSE, 100, 'Brasil', 2.1, '2020-03-21 09:21:55 PM', 15, 21, 12);
INSERT INTO aposta (aposta_ID, venceu_aposta, valor, aposta_vencedor, odd, data_hora, partida_ID, torneio_ID, id_usuario_aposta)
   VALUES (21, FALSE, 200, 'Brasil', 2.5, '2020-03-21 09:40:00 PM', 15, 21, 10);
INSERT INTO aposta (aposta_ID, venceu_aposta, valor, aposta_vencedor, odd, data_hora, partida_ID, torneio_ID, id_usuario_aposta)
   VALUES (22, TRUE, 100, 'Alemanha', 1.15, '2020-03-21 09:30:35 PM', 15, 21, 5);
INSERT INTO aposta (aposta_ID, venceu_aposta, valor, aposta_vencedor, odd, data_hora, partida_ID, torneio_ID, id_usuario_aposta)
   VALUES (23, FALSE, 800, 'Natus Vincere', 1.25, '2020-02-17 07:10:35 PM', 185, 241, 14);
INSERT INTO aposta (aposta_ID, venceu_aposta, valor, aposta_vencedor, odd, data_hora, partida_ID, torneio_ID, id_usuario_aposta)
   VALUES (24, TRUE, 400, 'G2', 2.1, '2020-02-17 07:11:54 PM', 185, 241, 15);
INSERT INTO aposta (aposta_ID, venceu_aposta, valor, aposta_vencedor, odd, data_hora, partida_ID, torneio_ID, id_usuario_aposta)
   VALUES (25, TRUE, 700, 'G2', 1.7, '2020-02-17 07:31:10 PM', 185, 241, 16);
INSERT INTO aposta (aposta_ID, venceu_aposta, valor, aposta_vencedor, odd, data_hora, partida_ID, torneio_ID, id_usuario_aposta)
   VALUES (26, FALSE, 200, 'Natus Vincere', 1.95, '2020-02-17 07:40:54 PM', 185, 241, 17);
INSERT INTO aposta (aposta_ID, venceu_aposta, valor, aposta_vencedor, odd, data_hora, partida_ID, torneio_ID, id_usuario_aposta)
   VALUES (27, TRUE, 100, 'G2', 1.25, '2020-02-17 07:41:27 PM', 185, 241, 10);
INSERT INTO aposta (aposta_ID, venceu_aposta, valor, aposta_vencedor, odd, data_hora, partida_ID, torneio_ID, id_usuario_aposta)
   VALUES (28, FALSE, 100, 'Natus Vincere', 2.7, '2020-02-17 07:55:02 PM', 185, 241, 12);
INSERT INTO aposta (aposta_ID, venceu_aposta, valor, aposta_vencedor, odd, data_hora, partida_ID, torneio_ID, id_usuario_aposta)
   VALUES (29, FALSE, 200, 'Pittsburgh Steelers', 3.5, '2020-05-06 08:00:55 PM', 45, 91, 18);
INSERT INTO aposta (aposta_ID, venceu_aposta, valor, aposta_vencedor, odd, data_hora, partida_ID, torneio_ID, id_usuario_aposta)
   VALUES (30, TRUE, 300, 'Dallas Cowboys', 1.15, '2020-05-06 08:00:14 PM', 45, 91, 19);
INSERT INTO aposta (aposta_ID, venceu_aposta, valor, aposta_vencedor, odd, data_hora, partida_ID, torneio_ID, id_usuario_aposta)
   VALUES (31, TRUE, 450, 'Dallas Cowboys', 1.15, '2020-05-06 08:07:53 PM', 45, 91, 20);
INSERT INTO aposta (aposta_ID, venceu_aposta, valor, aposta_vencedor, odd, data_hora, partida_ID, torneio_ID, id_usuario_aposta)
   VALUES (32, TRUE, 700, 'Dallas Cowboys', 1.15, '2020-05-06 07:08:46 PM', 45, 91, 21);
INSERT INTO aposta (aposta_ID, venceu_aposta, valor, aposta_vencedor, odd, data_hora, partida_ID, torneio_ID, id_usuario_aposta)
   VALUES (33, FALSE, 1000, 'Pittsburgh Steelers', 5.5, '2020-05-06 08:20:18 PM', 45, 91, 22);
INSERT INTO aposta (aposta_ID, venceu_aposta, valor, aposta_vencedor, odd, data_hora, partida_ID, torneio_ID, id_usuario_aposta)
   VALUES (34, TRUE, 1000, 'Dallas Cowboys', 1.1, '2020-05-06 08:37:24 PM', 45, 91, 11);
INSERT INTO aposta (aposta_ID, valor, aposta_vencedor, odd, data_hora, partida_ID, torneio_ID, id_usuario_aposta)
   VALUES (35, 500, 'Highlanders', 1.75, '2020-06-08 11:00:55 AM', 4, 199, 2);
INSERT INTO aposta (aposta_ID, valor, aposta_vencedor, odd, data_hora, partida_ID, torneio_ID, id_usuario_aposta)
   VALUES (36, 800, 'Chiefs', 1.4, '2020-06-08 11:00:14 AM', 4, 199, 3);
INSERT INTO aposta (aposta_ID, valor, aposta_vencedor, odd, data_hora, partida_ID, torneio_ID, id_usuario_aposta)
   VALUES (37, 1000, 'Highlanders', 1.75, '2020-06-08 11:00:55 AM', 4, 199, 8);
INSERT INTO aposta (aposta_ID, valor, aposta_vencedor, odd, data_hora, partida_ID, torneio_ID, id_usuario_aposta)
   VALUES (38, 900, 'Chiefs', 1.4, '2020-06-08 11:00:14 AM', 4, 199, 5);
INSERT INTO aposta (aposta_ID, venceu_aposta, valor, aposta_vencedor, odd, data_hora, partida_ID, torneio_ID, id_usuario_aposta)
   VALUES (39, TRUE, 1000, 'New Jersey Nets', 1.7, '2020-05-10 08:34:09 PM', 601, 1, 9);
INSERT INTO aposta (aposta_ID, venceu_aposta, valor, aposta_vencedor, odd, data_hora, partida_ID, torneio_ID, id_usuario_aposta)
   VALUES (40, FALSE, 1000, 'Los Angeles Lakers', 1.9, '2020-05-10 08:37:09 PM', 601, 1, 17);
INSERT INTO aposta (aposta_ID, venceu_aposta, valor, aposta_vencedor, odd, data_hora, partida_ID, torneio_ID, id_usuario_aposta)
   VALUES (41, FALSE, 100, 'Los Angeles Lakers', 2.0, '2020-05-10 08:35:00 PM', 601, 1, 10);
INSERT INTO aposta (aposta_ID, venceu_aposta, valor, aposta_vencedor, odd, data_hora, partida_ID, torneio_ID, id_usuario_aposta)
   VALUES (42, TRUE, 500, 'New Jersey Nets', 1.6, '2020-05-10 08:35:00 PM', 601, 1, 15);
INSERT INTO aposta (aposta_ID, venceu_aposta, valor, aposta_vencedor, odd, data_hora, partida_ID, torneio_ID, id_usuario_aposta)
   VALUES (43, TRUE, 500, 'New Jersey Nets', 1.9, '2020-05-08 06:04:19 PM', 591, 1, 7);
INSERT INTO aposta (aposta_ID, venceu_aposta, valor, aposta_vencedor, odd, data_hora, partida_ID, torneio_ID, id_usuario_aposta)
   VALUES (44, FALSE, 100, 'Chicago Bulls', 1.5, '2020-05-08 06:07:39 PM', 591, 1, 11);
INSERT INTO aposta (aposta_ID, venceu_aposta, valor, aposta_vencedor, odd, data_hora, partida_ID, torneio_ID, id_usuario_aposta)
   VALUES (45, FALSE, 600, 'Chicago Bulls', 1.8, '2020-05-08 06:25:50 PM', 591, 1, 13);
INSERT INTO aposta (aposta_ID, venceu_aposta, valor, aposta_vencedor, odd, data_hora, partida_ID, torneio_ID, id_usuario_aposta)
   VALUES (46, TRUE, 200, 'New Jersey Nets', 1.7, '2020-05-08 06:35:07 PM', 591, 1, 18);
INSERT INTO aposta (aposta_ID, venceu_aposta, valor, aposta_vencedor, odd, data_hora, partida_ID, torneio_ID, id_usuario_aposta)
   VALUES (47, FALSE, 800, 'Los Angeles Lakers', 2.1, '2020-05-05 04:04:19 PM', 595, 1, 16);
INSERT INTO aposta (aposta_ID, venceu_aposta, valor, aposta_vencedor, odd, data_hora, partida_ID, torneio_ID, id_usuario_aposta)
   VALUES (48, TRUE, 1000, 'Chicago Bulls', 1.5, '2020-05-05 04:07:39 PM', 595, 1, 19);
INSERT INTO aposta (aposta_ID, venceu_aposta, valor, aposta_vencedor, odd, data_hora, partida_ID, torneio_ID, id_usuario_aposta)
   VALUES (49, TRUE, 800, 'Chicago Bulls', 1.3, '2020-05-05 04:25:50 PM', 595, 1, 11);
INSERT INTO aposta (aposta_ID, venceu_aposta, valor, aposta_vencedor, odd, data_hora, partida_ID, torneio_ID, id_usuario_aposta)
   VALUES (50, FALSE, 500, 'Los Angeles Lakers', 2.5, '2020-05-05 04:35:07 PM', 595, 1, 4);
INSERT INTO aposta (aposta_ID, venceu_aposta, valor, aposta_vencedor, odd, data_hora, partida_ID, torneio_ID, id_usuario_aposta)
   VALUES (51, FALSE, 800, 'Chicago Bulls', 1.5, '2020-01-04 07:01:19 PM', 505, 1, 16);
INSERT INTO aposta (aposta_ID, venceu_aposta, valor, aposta_vencedor, odd, data_hora, partida_ID, torneio_ID, id_usuario_aposta)
   VALUES (52, TRUE, 1000, 'Boston Celtics', 1.9, '2020-01-04 07:08:39 PM', 505, 1, 15);
INSERT INTO aposta (aposta_ID, venceu_aposta, valor, aposta_vencedor, odd, data_hora, partida_ID, torneio_ID, id_usuario_aposta)
   VALUES (53, TRUE, 800, 'Boston Celtics', 1.4, '2020-01-04 07:37:50 PM', 505, 1, 6);
INSERT INTO aposta (aposta_ID, venceu_aposta, valor, aposta_vencedor, odd, data_hora, partida_ID, torneio_ID, id_usuario_aposta)
   VALUES (54, FALSE, 500, 'Chicago Bulls', 1.9, '2020-01-04 07:45:07 PM', 505, 1, 12);

/*USUARIO_PREMIUM*/

INSERT INTO usuario_premium (premium_ID, projeto_ID)
   VALUES (9, 1);
INSERT INTO usuario_premium (premium_ID, projeto_ID)
   VALUES (10, 2);
INSERT INTO usuario_premium (premium_ID, projeto_ID)
   VALUES (11, 3);
INSERT INTO usuario_premium (premium_ID, projeto_ID)
   VALUES (12, 4);
INSERT INTO usuario_premium (premium_ID, projeto_ID)
   VALUES (13, 5);
INSERT INTO usuario_premium (premium_ID, projeto_ID)
   VALUES (14, 6);
INSERT INTO usuario_premium (premium_ID, projeto_ID)
   VALUES (22, 7);
   
/*ORGANIZACAO*/

INSERT INTO organizacao (organizacao_ID, nome_org, CEO)
   VALUES (1, 'Logitech G', 'Bracken P. Darrell');
INSERT INTO organizacao (organizacao_ID, nome_org, CEO)
   VALUES (2, 'Gamers Club', 'Yuri Cerezo Uchiyama');
INSERT INTO organizacao (organizacao_ID, nome_org, CEO)
   VALUES (3, 'BENQ', 'Conway Lee');
INSERT INTO organizacao (organizacao_ID, nome_org, CEO)
   VALUES (4, 'Flamengo', 'Reinaldo Belotti');
INSERT INTO organizacao (organizacao_ID, nome_org, CEO)
   VALUES (5, 'Mastercard', 'Ajaypal Singh Banga');
INSERT INTO organizacao (organizacao_ID, nome_org, CEO)
   VALUES (6, 'Corsair', 'Andy Paul');

/*PERTENCE*/

INSERT INTO pertence (UserPremium_ID, UserOrg_ID)
   VALUES (9, 1);
INSERT INTO pertence (UserPremium_ID, UserOrg_ID)
   VALUES (9, 3);
INSERT INTO pertence (UserPremium_ID, UserOrg_ID)
   VALUES (10, 1);
INSERT INTO pertence (UserPremium_ID, UserOrg_ID)
   VALUES (10, 2);
INSERT INTO pertence (UserPremium_ID, UserOrg_ID)
   VALUES (11, 1);
INSERT INTO pertence (UserPremium_ID, UserOrg_ID)
   VALUES (11, 2);
INSERT INTO pertence (UserPremium_ID, UserOrg_ID)
   VALUES (11, 3);   
INSERT INTO pertence (UserPremium_ID, UserOrg_ID)
   VALUES (12, 1);
INSERT INTO pertence (UserPremium_ID, UserOrg_ID)
   VALUES (12, 2);
INSERT INTO pertence (UserPremium_ID, UserOrg_ID)
   VALUES (12, 3);  
INSERT INTO pertence (UserPremium_ID, UserOrg_ID)
   VALUES (13, 1);
INSERT INTO pertence (UserPremium_ID, UserOrg_ID)
   VALUES (13, 2);
INSERT INTO pertence (UserPremium_ID, UserOrg_ID)
   VALUES (14, 3); 
INSERT INTO pertence (UserPremium_ID, UserOrg_ID)
   VALUES (22, 2);
INSERT INTO pertence (UserPremium_ID, UserOrg_ID)
   VALUES (22, 3); 
INSERT INTO pertence (UserPremium_ID, UserOrg_ID)
   VALUES (9, 4);
INSERT INTO pertence (UserPremium_ID, UserOrg_ID)
   VALUES (9, 5);
INSERT INTO pertence (UserPremium_ID, UserOrg_ID)
   VALUES (10, 4);
INSERT INTO pertence (UserPremium_ID, UserOrg_ID)
   VALUES (10, 5);
INSERT INTO pertence (UserPremium_ID, UserOrg_ID)
   VALUES (10, 6);
INSERT INTO pertence (UserPremium_ID, UserOrg_ID)
   VALUES (11, 6);
INSERT INTO pertence (UserPremium_ID, UserOrg_ID)
   VALUES (11, 5);
INSERT INTO pertence (UserPremium_ID, UserOrg_ID)
   VALUES (12, 5);
INSERT INTO pertence (UserPremium_ID, UserOrg_ID)
   VALUES (12, 4);
INSERT INTO pertence (UserPremium_ID, UserOrg_ID)
   VALUES (13, 6);
INSERT INTO pertence (UserPremium_ID, UserOrg_ID)
   VALUES (14, 4);
INSERT INTO pertence (UserPremium_ID, UserOrg_ID)
   VALUES (22, 4);
INSERT INTO pertence (UserPremium_ID, UserOrg_ID)
   VALUES (22, 5); 
INSERT INTO pertence (UserPremium_ID, UserOrg_ID)
   VALUES (22, 6); 

/*PROJETO*/

INSERT INTO projeto (projeto_user_id, nome_projeto)
   VALUES (1, 'Torneio #1');
INSERT INTO projeto (projeto_user_id, nome_projeto)
   VALUES (1, 'Torneio 1v1');
INSERT INTO projeto (projeto_user_id, nome_projeto)
   VALUES (1, 'Pelada da Varzea');
INSERT INTO projeto (projeto_user_id, nome_projeto)
   VALUES (2, 'Basquete dos brothers');
INSERT INTO projeto (projeto_user_id, nome_projeto)
   VALUES (2, 'Vem no x1');
INSERT INTO projeto (projeto_user_id, nome_projeto)
   VALUES (3, 'Torneio aquele');
INSERT INTO projeto (projeto_user_id, nome_projeto)
   VALUES (4, 'Torneio 356');
INSERT INTO projeto (projeto_user_id, nome_projeto)
   VALUES (5, 'Pelada da facul');
INSERT INTO projeto (projeto_user_id, nome_projeto)
   VALUES (6, 'HAND TORN');
INSERT INTO projeto (projeto_user_id, nome_projeto)
   VALUES (7, 'TESTE');
INSERT INTO projeto (projeto_user_id, nome_projeto)
   VALUES (3, 'Dream Chasers Fall Classic');
INSERT INTO projeto (projeto_user_id, nome_projeto)
   VALUES (3, 'Shore Through the Uprights Tournament');
INSERT INTO projeto (projeto_user_id, nome_projeto)
   VALUES (5, 'Beast of the East Tournament');
INSERT INTO projeto (projeto_user_id, nome_projeto)
   VALUES (5, 'Black Diamond  Tournament');
INSERT INTO projeto (projeto_user_id, nome_projeto)
   VALUES (7, 'Turkey Trot Sandlot Challenge');
INSERT INTO projeto (projeto_user_id, nome_projeto)
   VALUES (1, 'Labor Day Goal Tournament');
INSERT INTO projeto (projeto_user_id, nome_projeto)
   VALUES (2, 'Shore Football Elite Tournament');   