use FantasyDreams;
DBQuery.shellBatchSize = 400;
db.esportes.insertMany(
[{"esporte":"futebol", "descricao":"pessoas correm e chutam uma bola, nada especial"},
{"esporte":"volei", "descricao":"EXPLOSAO XACABUM É A DANÇA DO VERÃO MELHOR ESPORTE"},
{"esporte":"hockey", "descricao":"gente com frio mas que curte uma briga"},
{"esporte":"futebol americano", "descricao":"pessoas gigantes correndo muitos quilometros"},
{"esporte":"league of legends", "descricao":"video jogo bem popular, partidas demoram uma eternidade"},
{"esporte":"overwatch", "descricao":"pouca gente ainda joga, nem sei se vai ter torneio"},
{"esporte":"polo", "descricao":"homens bem vestidos"},
{"esporte":"polo aquatico", "descricao":"homens musculosos"},
{"esporte":"rugby", "descricao":"igual futebol americano, mas sem a armadura, muita dor envolvida"},
{"esporte":"amarelinha", "descricao":"o esporte dos deuses"}]
);